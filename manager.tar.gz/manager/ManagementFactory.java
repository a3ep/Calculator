package com.enkio.madesms.manager;

import org.apache.log4j.Logger;

import java.beans.ConstructorProperties;

/**
 * Factory to create account management worker instances.
 */
public class ManagementFactory {

    /**
     * Logger.
     */
    private final static Logger log = Logger.getLogger(ManagementFactory.class);

    /**
     * Blocking item processor.
     */
    private final IBlockableProcessor itemProcessor;

    /**
     * Creates management factory instance.
     *
     * @param itemProcessor account processor
     */
    @ConstructorProperties({"itemProcessor"})
    public ManagementFactory(final IBlockableProcessor itemProcessor) {
        this.itemProcessor = itemProcessor;
        log.debug("Initialising Management Factory.");

    }

    /**
     * Creates instance of management worker.
     *
     * @param item item to process
     * @return account management worker instance
     */
    public ManagementWorker create(final IBlockable item) {

        return new ManagementWorker(item, itemProcessor);
    }
}
