package com.enkio.madesms.manager;

import java.io.IOException;

/**
 * Abstract processor for blocking items.
 */
public abstract class AbstractProcessor implements IBlockableProcessor {

    /**
     * Processor name.
     */
    protected String name;

    /**
     * Processes a blocking item.
     *
     * @param item blocking item
     * @return true if the item processed successfully, false otherwise
     * @throws IOException in case of database I/O error
     */
    public abstract boolean process(IBlockable item) throws IOException;

    /**
     * Gets processor name.
     *
     * @return processor name
     */
    public String getName() {
        return name;
    }
}
