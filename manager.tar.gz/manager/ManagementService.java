package com.enkio.madesms.manager;

import com.enkio.madesms.core.AbstractService;
import com.enkio.madesms.core.NamedThreadFactory;
import org.apache.log4j.Logger;

import java.beans.ConstructorProperties;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Provides blocked items processing.
 */
public class ManagementService extends AbstractService {

    /**
     * Logger.
     */
    private static final Logger log = Logger.getLogger(ManagementService.class);

    /**
     * Thread pool.
     */
    private final ThreadPoolExecutor pool;

    /**
     * Items finder to find items for processing.
     */
    private final IBlockableFinder itemFinder;

    /**
     * Period of an item blocking (in days).
     */
    private final int blockingPeriod;

    /**
     * Notification send status.
     */
    private final boolean isNotified;

    /**
     * Max time of an item processing.
     */
    private final long maxProcessingTime;

    /**
     * Creator of the management worker threads.
     */
    private final ManagementFactory factory;

    /**
     * Service name.
     */
    private final String serviceName;

    /**
     * Single thread name.
     */
    private final String threadName;

    /**
     * Date formatter
     */
    private final SimpleDateFormat dateFormatter;

    /**
     * Initialize management service.
     *
     * @param itemFinder        blocked items finder
     * @param factory           factory for threads creation
     * @param threadCount       number of threads
     * @param isNotified        notification send status
     * @param blockingPeriod    period of an item blocking (in days)
     * @param maxProcessingTime max time of an item processing
     * @param serviceName       service name
     * @param threadName        single thread name
     */
    @ConstructorProperties({"itemFinder", "factory", "threadCount", "isNotified", "blockingPeriod", "maxProcessingTime",
            "serviceName", "threadName"})
    public ManagementService(final IBlockableFinder itemFinder,
                             final ManagementFactory factory,
                             final int threadCount,
                             final boolean isNotified,
                             final int blockingPeriod,
                             final long maxProcessingTime,
                             final String serviceName,
                             final String threadName) {
        super(serviceName);
        this.factory = factory;
        this.blockingPeriod = blockingPeriod;
        this.isNotified = isNotified;
        this.maxProcessingTime = maxProcessingTime;
        this.serviceName = serviceName;
        this.threadName = threadName;
        this.itemFinder = itemFinder;
        dateFormatter = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss z");
        dateFormatter.setTimeZone(TimeZone.getTimeZone("GMT"));
        final SynchronousQueue<Runnable> workerQueue = new SynchronousQueue<Runnable>();
        this.pool = new ThreadPoolExecutor(threadCount,
                threadCount,
                0L,
                TimeUnit.MILLISECONDS,
                workerQueue,
                new NamedThreadFactory(threadName),
                new RejectedExecutionHandler() {
                    public void rejectedExecution(Runnable r, ThreadPoolExecutor pool) {
                        try {
                            pool.getQueue().put(r);
                        } catch (InterruptedException ie) {
                            Thread t = new Thread(r);
                            t.start();
                            AbstractService.interruptThread(t);
                        }
                    }
                });
        log.debug("Initialising Management Service. Incoming parameters: threadCount: " + threadCount +
                "; isNotified: " + isNotified +
                "; blockingPeriod: " + blockingPeriod +
                "; maxProcessingTime: " + maxProcessingTime +
                "; serviceName: " + serviceName +
                "; threadName: " + threadName);
    }

    /**
     * Processes blocked items.
     */
    public void run() {
        log.info(serviceName + ": starting service..");
        while (!pool.isShutdown()) {
            try {
                final long curTime = System.currentTimeMillis();
                final long timeOfBlocking =
                        curTime - TimeConverter.convertDaysToMillis(blockingPeriod);
                log.debug("Try to process items blocked in " + dateFormatter.format(new Date(timeOfBlocking)));
                final IBlockable item = itemFinder.getNext(curTime,
                        timeOfBlocking, maxProcessingTime, isNotified);
                if (item != null) {
                    pool.execute(factory.create(item));
                } else {
                    TimeUnit.SECONDS.sleep(60);
                }
            } catch (InterruptedException ie) {
                break;
            } catch (Throwable t) {
                log.error("<0> Error executing " + threadName + " task", t);
            }
        }

        // Wait for thread termination
        while (!pool.isTerminated()) {
        }
        log.info(serviceName + ": successful shutdown");
    }

    /**
     * Method for gracefully shutting down the service.
     */
    @Override
    public void shutdown() {
        log.info(serviceName + ": shutting down service..");
        List<Runnable> workQueue = pool.shutdownNow();
        for (Runnable element : workQueue) {
            Thread task = new Thread(element);
            task.start();
            AbstractService.interruptThread(task);
        }

        AbstractService.interruptThread(this);
    }
}
