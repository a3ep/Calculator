package com.enkio.madesms.manager;

import com.enkio.madesms.db.collections.account.Account;
import org.apache.log4j.Logger;

import java.beans.ConstructorProperties;
import java.io.IOException;

/**
 * Provides notification sending to a blocking item account.
 */
public class NotifyingProcessor extends AbstractProcessor {

    /**
     * Logger.
     */
    private final static Logger log = Logger.getLogger(NotifyingProcessor.class);

    /**
     * Email notifier.
     */
    private final Notifier notifier;

    /**
     * Blocking item finder.
     */
    private final IBlockableFinder itemFinder;

    /**
     * Blocking item relay holder.
     */
    private final IBlockableRelayHolder relayHolder;


    /**
     * Creates notifying processor instance.
     *
     * @param name        processor name
     * @param notifier    email notifier
     * @param itemFinder  blocking item finder
     * @param relayHolder blocking item relay holder
     */
    @ConstructorProperties({"name", "notifier", "itemFinder", "relayHolder"})
    public NotifyingProcessor(final String name,
                              final Notifier notifier,
                              final IBlockableFinder itemFinder,
                              final IBlockableRelayHolder relayHolder) {
        this.name = name;
        this.notifier = notifier;
        this.itemFinder = itemFinder;
        this.relayHolder = relayHolder;
        log.debug("Initialising Notifying Processor. Incoming parameter: name: " + name);
    }

    /**
     * Sends a notification to blocked item account.
     *
     * @param item blocked item
     * @return true if the notification sent successfully, false otherwise
     * @throws IOException in case of database I/O error
     */
    public boolean process(final IBlockable item) throws IOException {
        boolean res = false;
        final Account account = relayHolder.getAccount(item.getObjectId());
        try {
            if (res = (account != null)) {
                if (relayHolder.isNotifiable(item.getObjectId())) {
                    notifier.send(account, item.getBlockStatus(), item.getName());
                }
                itemFinder.setNotified(item.getObjectId(), true);
            } else {
                log.error("<0> Account not found for item, name: " + item.getName() + ", id: " + item.getObjectId());
            }
        } catch (IllegalArgumentException iae) {
            log.error("<" + item.getUsername() + "> Couldn't send notification email on notifying item, item name: " +
                    item.getName() + ". Reason: incorrect blocked status.");
        }

        return res;
    }
}