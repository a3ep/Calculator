package com.enkio.madesms.manager;

import org.apache.log4j.Logger;

import java.io.IOException;

/**
 * Provides an item (account or keyword) processing.
 */
public class ManagementWorker implements Runnable {

    /**
     * Logger.
     */
    private final static Logger log = Logger.getLogger(ManagementWorker.class);

    /**
     * Blocking item to process.
     */
    private final IBlockable item;

    /**
     * Blocking item processor.
     */
    private final IBlockableProcessor itemProcessor;

    /**
     * Creates item management worker instance.
     *
     * @param item          item to process
     * @param itemProcessor item processor
     */
    public ManagementWorker(final IBlockable item,
                            final IBlockableProcessor itemProcessor) {
        this.item = item;
        this.itemProcessor = itemProcessor;
    }

    /**
     * Processes an item.
     */
    public void run() {
        try {
            log.debug("<" + item.getUsername() + "> Processing started...\n" +
                    "item name [" + item.getDisplayName() + "]");
            itemProcessor.process(item);
            log.info("<" + item.getUsername() + "> Processing finished successfully for item [" + item.getDisplayName() +
                    "], processor name [" + itemProcessor.getName() + "]");
        } catch (IOException e) {
            log.error("<" + item.getUsername() + "> I/O error during item processing, item name: " + item.getDisplayName());
        } catch (Throwable e) {
            log.error("<" + item.getUsername() + "> Unexpected exception", e);
        }
    }
}
