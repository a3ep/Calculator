package com.enkio.madesms.manager;

import com.enkio.madesms.db.collections.account.Account;
import org.apache.log4j.Logger;

import java.beans.ConstructorProperties;
import java.io.IOException;

/**
 * Provides an blocking item removing.
 */
public class RemovingProcessor extends AbstractProcessor {

    /**
     * Logger.
     */
    private final static Logger log = Logger.getLogger(RemovingProcessor.class);

    /**
     * Blocking item relay holder.
     */
    private final IBlockableRelayHolder relayHolder;

    /**
     * Email notifier
     */
    private final Notifier notifier;

    /**
     * Creates an blocking item removing processor.
     *
     * @param name        processor name
     * @param relayHolder blocked item relay holder
     * @param notifier    email notifier
     */
    @ConstructorProperties({"name", "relayHolder", "notifier"})
    public RemovingProcessor(final String name,
                             final IBlockableRelayHolder relayHolder,
                             final Notifier notifier) {
        this.name = name;
        this.relayHolder = relayHolder;
        this.notifier = notifier;
        log.debug("Initialising Removing Processor. Incoming parameter: name: " + name);

    }

    /**
     * Removes a blocking item.
     *
     * @param item blocking item
     * @return true if the item removed successfully, false otherwise
     * @throws IOException in case of database I/O error
     */
    public boolean process(final IBlockable item) throws IOException {
        boolean res;
        final Account account = relayHolder.getAccount(item.getObjectId());
        if (account != null) {
            try {
                if (relayHolder.isNotifiable(item.getObjectId())) {
                    notifier.send(account, item.getBlockStatus(), item.getName());
                } else {
                    log.debug("<" + item.getUsername() + "> Item" + item.getName() + "is not notifiable");
                }
            } catch (IllegalArgumentException iae) {
                log.error("<" + item.getUsername() + "> Couldn't send notification email on removing item, item name: " +
                        item.getName() + ". Reason: incorrect blocked status.");
            }
        } else {
            log.error("<" + item.getUsername() + "> Couldn't send notification email on removing item, item name: " + item.getName());
        }
        res = relayHolder.remove(item.getObjectId());

        return res;
    }
}
