package com.enkio.madesms.manager;

import com.enkio.madesms.db.collections.account.BlockedStatus;
import org.bson.types.ObjectId;

/**
 * Interface for a blocking item (user account or keyword).
 */
public interface IBlockable {

    /**
     * Gets a document record id.
     *
     * @return record id
     */
    public ObjectId getObjectId();

    /**
     * Gets a human readable name.
     *
     * @return human readable name
     */
    public String getDisplayName();

    /**
     * Gets a name.
     *
     * @return human name
     */
    public String getName();

    /**
     * Gets username
     *
     * @return username
     */
    public String getUsername();

    /**
     * Gets block status
     *
     * @return block status
     */
    public BlockedStatus getBlockStatus();
}
