package com.enkio.madesms.manager;

import java.io.IOException;

/**
 * Interface for class that provides blocking items processing.
 */
public interface IBlockableProcessor {

    /**
     * Gets processor name.
     *
     * @return processor name
     */
    public String getName();

    /**
     * Processes a blocking item.
     *
     * @param item blocking item
     * @return true if the item processed successfully, false otherwise
     * @throws IOException in case of database I/O error
     */
    public boolean process(final IBlockable item) throws IOException;
}
