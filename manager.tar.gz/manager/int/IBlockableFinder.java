package com.enkio.madesms.manager;

import org.bson.types.ObjectId;

import java.io.IOException;

/**
 * Interface for class that provides blocking items finding.
 */
public interface IBlockableFinder {

    /**
     * Gets blocking item by record id.
     *
     * @param objectId record id
     * @return blocking item
     * @throws IOException in case of database I/O error
     */
    public IBlockable getById(final ObjectId objectId) throws IOException;

    /**
     * Gets next item for processing.
     *
     * @param curTime      current time
     * @param blockingTime time of a blocking
     * @param processTime  max time of a processing
     * @param isNotified   notification send status
     * @return item to process
     * @throws IOException in case of database I/O error
     */
    public IBlockable getNext(final long curTime,
                              final long blockingTime,
                              final long processTime,
                              final boolean isNotified) throws IOException;

    /**
     * Sets notification send status.
     *
     * @param objectId record id
     * @param status   status of notification sending
     * @return true id status updated successfully, false otherwise
     * @throws IOException in case of database I/O error
     */
    public boolean setNotified(final ObjectId objectId,
                               final boolean status) throws IOException;
}
